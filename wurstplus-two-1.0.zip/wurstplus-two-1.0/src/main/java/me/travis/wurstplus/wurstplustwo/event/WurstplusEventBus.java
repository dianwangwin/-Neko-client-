package me.travis.wurstplus.wurstplustwo.event;

import me.zero.alpine.fork.bus.EventBus;
import me.zero.alpine.fork.bus.EventManager;

public class WurstplusEventBus {
	public static final EventBus EVENT_BUS = new EventManager();
}